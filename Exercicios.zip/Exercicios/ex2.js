function verificarNumero() {
    let numero = document.getElementById("numero").value;
  
    if(numero % 2 === 0) {
      alert("A variável lida do número é par");
    } else {
      alert("A variável do número é ímpar");
    }
  }


